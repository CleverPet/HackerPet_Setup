Download Particle CLI 
https://docs.particle.io/getting-started/developer-tools/cli/

Download and install Python 3 
https://www.python.org/downloads/

For windows open the cmd prompt
Run the cleverPet_Setup.bat

or for mac or linux run 
python cleverPet_Setup.py

Any issues, email support@clever.pet

Brian