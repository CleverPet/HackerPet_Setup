#! /usr/bin/python3
import subprocess, io
# Verbose = True

def PopenResultStream( result, verbose = True, output = True ) -> list:
    CLEAR = '\x1b[2K'
    # print(f'dir(result) == {dir(result)}')
    outputList = []
    for line in io.TextIOWrapper( result, encoding="utf-8"):
        saveLine = line.rstrip()
        # print(f'line == {line}')
        outputList.append( saveLine )
        # print(f'outputList == {outputList}')

        if verbose == True:
            # print('verbosing')
            print( saveLine )
    if output == True:
        # print(f'#################### outputing list...: {outputList}')
        return outputList


######## Interactive cmd
# import subprocess


# p = subprocess.Popen(['your_command'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
def interactive( commandList: list ):
    p = subprocess.Popen( commandList, stdin=subprocess.PIPE, stdout=subprocess.PIPE )

    output, _ = p.communicate()
    while True:
        line = input('Enter your response: ')
        if not line:
            break
        p.stdin.write(line.encode())

# def bgOpen( commandList: list ):
#     '''### This does everything as you would expect
#     #### opens a program and continues on and prints out the results as it happens.'''
#     result = subprocess.Popen( commandList, universal_newlines=True, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE )
#     for line in result.stdout:
#        print(line, end='')
#     # print(result.communicate()[0])
#     # print(type(result))
#     # print(type(result.stdout))
#     # PopenResultStream( result.communicate()[0] )
       
# def bgOpen_old( commandList: list ) -> list:
#     CLEAR = '\x1b[2K'
#     result = subprocess.Popen( commandList, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True )
#     outputList = []
#     # print( 'Download progress below...' )
#     # Prints and replaces each line as subprocess outputs info.
#     for line in io.TextIOWrapper( result.stdout, encoding="utf-8" ):
#         # print( '.', end=CLEAR )
#         saveLine = line.rstrip()
#         print(saveLine)
       
#         # print( saveLine, end='\r' )
#         outputList.append( saveLine )
#     return outputList

def open( commandList: list, verbose = False, output = True, shellOption = False  ) -> list:
    CLEAR = '\x1b[2K'
    # print(f'\n\nStarting bgOpen command:{commandList[3]}\n\n')
    result = subprocess.Popen( commandList, shell=shellOption, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True )
    outputList = []
    # if commandList[3]:
    #     print(f'result.communicate[0] == {result.communicate()[0]}')
    # input(f'result == {result.stdout}')
    # print( 'Download progress below...' )
    # Prints and replaces each line as subprocess outputs info.
    outputList = PopenResultStream( result.stdout, verbose = verbose, output = output  )
    # for line in io.TextIOWrapper( result.stdout, encoding="utf-8" ):
    #     # print( '.', end=CLEAR )
    #     saveLine = line.rstrip()
    #     print(saveLine)
    return outputList